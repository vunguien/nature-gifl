import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import Chart from './pages/Chart';
import Watering from './pages/Watering';
import Controller from './pages/Controller';
import NotFound from './components/NotFound';
import Layout from './components/Layout';
import LayoutManager from './components/LayoutManager';
import {  useEffect, useState } from 'react';
import DashboardManager from './pages/DashboardManager';

const data = {
  Room1: {
    Roomname: 'Room 1',
    Mode: 'bloom',
    Day: '42',
    SensorEnvironment: {
      Temp: 27.5,
      Humi: '60',
      Co2: '1133',
      VPD: 1.4,
    },
    SensorEC: {
      PPM: '2.2',
      Temp: '23',
      Humi: '89',
    },
    Co2Mode: {
      Mode: 'Auto',
      ValueOff: '800',
      ValueOn: '900',
    },
    StateDen: '1',
    StateBom: '0',
    StateKhuay: '1',
    StateTuoi: '0',
    StateCo2: '1',
    StateXa: '0',
    StateRO: '1',
  },
  Room2: {
    Roomname: 'Room 2',
    Mode: 'bloom',
    Day: '45',
    SensorEnvironment: {
      Temp: 27.5,
      Humi: '60',
      Co2: '1133',
      VPD: 1.4,
    },
    SensorEC: {
      PPM: '2.2',
      Temp: '23',
      Humi: '89',
    },
    Co2Mode: {
      Mode: ' Auto',
      ValueOff: '800',
      ValueOn: '900',
    },
    StateDen: '1',
    StateBom: '0',
    StateKhuay: '1',
    StateTuoi: '0',
    StateCo2: '1',
    StateXa: '0',
    StateRO: '1',
  },
};

export default function App() {
  const [roomData, setRoomData] = useState(data.Room1)

  useEffect(() => {
    setRoomData(data.Room1)
  }, [])

  return (
    <Router>
      <Routes>
        <Route
          path="/"
          element={
            <Layout>
              <Dashboard data={roomData} />
            </Layout>
          }
        />
        <Route
          path="dashboard"
          element={
            <Layout>
              <Dashboard data={roomData} />
            </Layout>
          }
        />
        <Route
          path="chart"
          element={
            <Layout>
              <Chart />
            </Layout>
          }
        />
        <Route
          path="watering"
          element={
            <Layout>
              <Watering />
            </Layout>
          }
        />
        <Route
          path="controller"
          element={
            <Layout>
              <Controller />
            </Layout>
          }
        />
         <Route
          path="dashboard-manager"
          element={
            <LayoutManager>
              <DashboardManager  data={roomData}/>
            </LayoutManager>
          }
        />
        <Route
          path="*"
          element={
            <Layout>
              <NotFound />
            </Layout>
          }
        />
      </Routes>
    </Router>
  );
}

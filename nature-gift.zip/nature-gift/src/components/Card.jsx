import React from 'react';
import CardItem from './CardItem';
import SwitchButton from './SwitchButton';
import StatusButton from './StatusButton';
import { ACTIVE } from '../constants/consts';

function Card({ data, title, isSwitchButton, onChangeStatus = () => {} }) {
  return (
    <div>
      <h2 className="text-lg border-b-[1px] font-bold border-[dimgrey]">
        {title}
      </h2>
      <div className="py-2">
        {data.map((item, index) => {
          return (
            <CardItem
              text={item.text}
              key={index}
              icon={
                isSwitchButton ? (
                  <SwitchButton
                    checked={item.status === ACTIVE}
                    onChange={() => onChangeStatus(item)}
                  />
                ) : (
                  <StatusButton isOn={item.status === ACTIVE} />
                )
              }
            />
          );
        })}
      </div>
    </div>
  );
}

export default Card;

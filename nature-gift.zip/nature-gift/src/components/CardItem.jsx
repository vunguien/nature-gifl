import React from 'react';

function CardItem({ text = "", icon }) {
  return (
    <div className='flex items-center justify-between px-4 py-1'>
      <div className='text-base'>{text}</div>
      <div>{icon}</div>
    </div>
  );
}

export default CardItem;

import React from 'react';
import CardItem from './CardItem';
import StatusButton from './StatusButton';

function CardStatus({ isOn, text }) {
  return (
    <CardItem
      text={text}
      icon={<StatusButton isOn={isOn} />}
    />
  );
}

export default CardStatus;

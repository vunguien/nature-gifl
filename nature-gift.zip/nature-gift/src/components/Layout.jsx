import { Disclosure } from '@headlessui/react';
import { Bars3Icon, XMarkIcon } from '@heroicons/react/24/outline';
import { Link, useLocation } from 'react-router-dom';
import img from '../logo.png'

const navigation = [
  { name: 'Dashboard', href: '/dashboard' },
  { name: 'Chart', href: '/chart' },
  { name: 'Controller', href: '/controller' },
  { name: 'Wartering', href: '/watering' },
  { name: 'Dashboard Manager', href: '/dashboard-manager' },
];

function classNames(...classes) {
  return classes.filter(Boolean).join(' ');
}

export default function Layout(props) {
  const location = useLocation();

  // Access the pathname from the location object
  const currentPath = location.pathname;

  return (
    <div className="bg-[#DACEB4] h-screen h-full">
      <div className="px-10">
        <div className="min-h-full">
          <div className="flex items-center justify-center pt-2">
            <div className="flex-shrink-0">
              <img
                className="h-24 w-24"
                src={img}
                alt="Nartual Gift"
              />
            </div>
          </div>
          <Disclosure as="nav" className="bg-[#EFE3CA] rounded-md mt-2">
            {({ open }) => (
              <>
                <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                  <div className="flex h-16 items-center justify-between">
                    <div className="flex items-center">
                      <div className="flex-shrink-0">
                        <img
                          className="h-8 w-8"
                          src={img}
                          alt="Your Company"
                        />
                      </div>
                      <div className="hidden md:block">
                        <div className="ml-10 flex items-baseline space-x-4">
                          {navigation.map((item) => (
                            <Link
                              key={item.name}
                              to={item.href}
                              className={classNames(
                                item.href === currentPath
                                  ? 'bg-[#DACEB4] text-black'
                                  : 'text-black-300 hover:bg-[#DACEB4] hover:text-white',
                                'rounded-md px-3 py-2 text-sm font-medium'
                              )}
                              aria-current={
                                item.href === currentPath ? 'page' : undefined
                              }
                            >
                              {item.name}
                            </Link>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center justify-end text-black text-sm flex-1">
                      <div className='bg-[#DACEB4] w-8 h-5 border-[1px] text-center rounded-md mr-4 cursor-pointer hover:bg-gray-700'>1</div>
                      <div className='bg-[#DACEB4] w-8 h-5 border-[1px] text-center rounded-md mr-4 cursor-pointer hover:bg-gray-700'>2</div>
                      <div className='bg-[#DACEB4] w-8 h-5 border-[1px] text-center rounded-md mr-4 cursor-pointer hover:bg-gray-700'>3</div>
                      <div className='bg-[#DACEB4] w-8 h-5 border-[1px] text-center rounded-md cursor-pointer hover:bg-gray-700'>4</div>
                    </div>
                    <div className="hidden md:block"></div>
                    <div className="-mr-2 flex md:hidden">
                      {/* Mobile menu button */}
                      <Disclosure.Button className="relative inline-flex items-center justify-center rounded-md bg-color-box p-2 text-gray-400 hover:bg-gray-700 hover:text-white focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-800">
                        <span className="absolute -inset-0.5" />
                        <span className="sr-only">Open main menu</span>
                        {open ? (
                          <XMarkIcon
                            className="block h-6 w-6"
                            aria-hidden="true"
                          />
                        ) : (
                          <Bars3Icon
                            className="block h-6 w-6"
                            aria-hidden="true"
                          />
                        )}
                      </Disclosure.Button>
                    </div>
                  </div>
                </div>

                <Disclosure.Panel className="md:hidden">
                  <div className="space-y-1 px-2 pb-3 pt-2 sm:px-3">
                    {navigation.map((item) => (
                      <Link
                        key={item.name}
                        to={item.href}
                        className={classNames(
                          item.href === currentPath
                            ? 'bg-gray-900 text-white'
                            : 'text-gray-300 hover:bg-gray-700 hover:text-white',
                          'block rounded-md px-3 py-2 text-base font-medium'
                        )}
                        aria-current={
                          item.href === currentPath ? 'page' : undefined
                        }
                      >
                        {item.name}
                      </Link>
                    ))}
                  </div>
                </Disclosure.Panel>
              </>
            )}
          </Disclosure>

          {props.children}
        </div>
      </div>
    </div>
  );
}

import { Disclosure } from '@headlessui/react';
import { Bars3Icon, XMarkIcon } from '@heroicons/react/24/outline';
import { Link, useLocation } from 'react-router-dom';
import img from '../logo.png'

const navigation = [
  { name: 'Dashboard', href: '/dashboard' },
  { name: 'Chart', href: '/chart' },
  { name: 'Controller', href: '/controller' },
  { name: 'Wartering', href: '/watering' },
  { name: 'Dashboard Manager', href: '/dashboard-manager' },
];

function classNames(...classes) {
  return classes.filter(Boolean).join(' ');
}

export default function LayoutManager(props) {
  const location = useLocation();

  // Access the pathname from the location object
  const currentPath = location.pathname;

  return (
    <div className="bg-[#DACEB4] h-full">
      <div className="">
        <div className="">
          <div className="flex items-center justify-center pt-2">
            <div className="flex-shrink-0">
              {/* <img
                className="h-48 w-48"
                src={img}
                alt="Nartual Gift"
              /> */}
            </div>
          </div>
          <Disclosure as="nav" className="bg-[#EDE7D9] rounded-md mt-2 p-8">
            {({ open }) => (
              <>
                <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                  <div className="flex h-16 items-center justify-between">
                    <div className="flex items-center">
                      <div className="flex-shrink-0">
                        {/* <img
                          className="h-8 w-8"
                          src={img}
                          alt="Your Company"
                        /> */}
                      </div>
                      <div className="hidden md:block">
                        <h1 class="text-black text-8xl"><b>Dashboard Manager</b></h1>
                      </div>
                    </div>
                    <div className="hidden md:block"></div>
                  </div>
                </div>

                <Disclosure.Panel className="md:hidden">
                  <div className="space-y-1 px-2 pb-3 pt-2 sm:px-3">
                    {navigation.map((item) => (
                      <Link
                        key={item.name}
                        to={item.href}
                        className={classNames(
                          item.href === currentPath
                            ? 'bg-gray-900 text-white'
                            : 'text-gray-300 hover:bg-gray-700 hover:text-white',
                          'block rounded-md px-3 py-2 text-base font-medium'
                        )}
                        aria-current={
                          item.href === currentPath ? 'page' : undefined
                        }
                      >
                        {item.name}
                      </Link>
                    ))}
                  </div>
                </Disclosure.Panel>
              </>
            )}
          </Disclosure>

          {props.children}
        </div>
      </div>
    </div>
  );
}

import React, { useState } from 'react';

import CardStatus from '../components/CardStatus';
import {
  bgSensorEnvObj,
  unitSensorEnv,
  ACTIVE,
  listCo2Mode,
} from '../constants/consts';

function StateBox({ data }) {
  let [co2Mode, setCo2Mode] = useState('On');
  return (
    <div className="">
      <div class="grid grid-cols-3 max-[600px]:grid-cols-1">
        {/* ENVIROMENT */}
        <div class="mr-2">
          <h2 className="text-xl mb-1">Environment</h2>
          <div class="grid grid-rows bg-[#b3a079] rounded-md p-1 ">
            {Object.keys(data.SensorEnvironment).map((key = {}, index) => {
              return (
                <div className="flex items-center space-x-1" key={index}>
                  <div
                    className={`${bgSensorEnvObj[key]} w-6 h-6  rounded-md`}
                  ></div>
                  <div>
                    <div class="text-white">{key}</div>
                    <div class="text-white">
                      {data.SensorEnvironment[key]}
                      {unitSensorEnv[key]}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        {/* EC2 */}
        <div class="mr-2">
          <h2 className="text-xl  mb-1">Sensor EC</h2>
          <div class="grid grid-rows bg-[#b3a079] rounded-md p-1 ">
            {Object.keys(data.SensorEC).map((key = {}, index) => {
              return (
                <div className="flex items-center space-x-1" key={index}>
                  <div
                    className={`${bgSensorEnvObj[key]} w-6 h-6 rounded-md`}
                  ></div>
                  <div>
                    <div class="text-white">{key}</div>
                    <div class="text-white">{data.SensorEC[key]}-89%</div>
                  </div>
                </div>
              );
            })}
            <div>
              <div className="flex items-center justify-center flex-1 w-full mb-1">
                {listCo2Mode.map((item) => {
                  const activeMode = co2Mode === item.mode;
                  return (
                    <button
                      className={`px-2 text-[10px] ${
                        activeMode ? 'bg-red-500 text-white' : 'bg-gray-500'
                      }`}
                      onClick={() => setCo2Mode(item.mode)}
                    >
                      {item.text}
                    </button>
                  );
                })}
              </div>
              <div className="flex items-center justify-center text-[11px]">
                <button className={`px-2 py-1 bg-blue-500 rounded-sm`}>
                  {data?.Co2Mode?.ValueOff || 0}
                </button>
                <button className={`px-2 py-1 bg-red-500 rounded-sm`}>
                  {data?.Co2Mode?.ValueOn || 0}
                </button>
              </div>
            </div>
          </div>
        </div>
        {/* DEVICE */}
        <div>
          <h2 className="text-xl mb-1">Device</h2>
          <div class="grid grid-rows bg-[#b3a079] rounded-md p-1 ">
            <CardStatus isOn={data.StateDen === ACTIVE} text="Đèn" />
            <CardStatus isOn={data.StateBom === ACTIVE} text="Bơm" />
            <CardStatus isOn={data.StateKhuay === ACTIVE} text="Khuấy" />
            <CardStatus isOn={data.StateTuoi === ACTIVE} text="Tưới" />
            <CardStatus isOn={data.StateCo2 === ACTIVE} text="CO2" />
            <CardStatus isOn={data.StateXa === ACTIVE} text="Xả" />
            <CardStatus isOn={data.StateRO === ACTIVE} text="RO" />
          </div>
        </div>
      </div>
    </div>
  );
}

export default StateBox;

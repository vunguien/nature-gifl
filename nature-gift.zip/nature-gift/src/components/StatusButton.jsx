import React from 'react';

function StatusButton({ isOn }) {
  return (
    <div
      className={`rounded-full w-3 h-3 ${isOn ? 'bg-green-500' : 'bg-white'}`}
    ></div>
  );
}

export default StatusButton;

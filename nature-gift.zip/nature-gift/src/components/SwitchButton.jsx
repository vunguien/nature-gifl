// import { Switch } from '@headlessui/react';

import { useState } from 'react';

// function SwitchButton({ value, onChange }) {
//   return (
//     <div>
//       {/* <Switch
//         checked={enabled}
//         onChange={onChange}
//         className={`${enabled ? 'bg-blue-600' : 'bg-blue-100'}
//           relative inline-flex h-[15px] w-[20px] shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus-visible:ring-2  focus-visible:ring-white/75`}
//       >
//         <span
//           aria-hidden="true"
//           className={`${enabled ? 'translate-x-9' : 'translate-x-0'}
//             pointer-events-none inline-block h-[15px] w-[20px] transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out`}
//         />
//       </Switch> */}

//       <label className="relative inline-flex items-center mb-5 cursor-pointer">
//         <input type="checkbox" value={value} className="sr-only peer" onChange={() => onChange(value)} />
//         <div className="w-9 h-5 bg-gray-100 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-400 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
//       </label>
//     </div>
//   );
// }

// export default SwitchButton;

const SwitchButton = ({ checked, onChange }) => {
  return (
    <div className="flex items-center">
      <input
        type="checkbox"
        id="switch"
        className="hidden"
        checked={checked}
        onChange={onChange}
      />
      <label
        htmlFor="switch"
        className={`cursor-pointer ${
          checked ? 'bg-blue-500' : 'bg-gray-300'
        } relative inline-block h-4 w-7 border-2 border-gray-300 rounded-full transition-all duration-300`}
      >
        <span
          className={`block h-3 w-3 rounded-full bg-white shadow-md transform ${
            checked ? 'translate-x-3' : 'translate-x-0'
          } transition-transform duration-300 ease-in-out`}
        ></span>
      </label>
    </div>
  );
};

export default SwitchButton;

export const bgSensorEnvObj = {
  PPM: 'bg-yellow-600',
  Temp: 'bg-red-400',
  Humi: 'bg-blue-400',
  Co2: 'bg-yellow-600',
  VPD: 'bg-purple-500',
};

export const unitSensorEnv = {
  Temp: 'o C',
  Humi: '%',
  Co2: 'ppm',
  VPD: 'kpa',
};

export const ACTIVE = '1';
export const INACTIVE = '0';

export const listCo2Mode = [
  {
    mode: 'On',
    text: 'On',
  },
  {
    mode: 'Auto',
    text: 'Auto',
  },
  {
    mode: 'Off',
    text: 'Off',
  },
];

export const listWateringMode = [
  {
    mode: '1',
    text: 'o',
  },
  {
    mode: '0',
    text: '%',
  },
];

export const textDisplay = {
  StateDen: 'Đèn',
  StateBom: 'Bơm',
  StateKhuay: 'Khuấy',
  StateTuoi: 'Tưới',
  StateCo2: 'Co2',
  StateXa: 'Xả',
  StateRO: 'RO',
};

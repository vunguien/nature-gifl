import React from 'react';
import LineChart from './LineChart';

export default function Chart() {
  return (
    <div className="mt-4">
      <main className="rounded-md bg-gray-800 min-h-full">
        <LineChart />
      </main>
    </div>
  );
}

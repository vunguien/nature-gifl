import React from 'react';
import Card from '../components/Card';
import { INACTIVE, textDisplay } from '../constants/consts';

const data = {
  mini1: {
    button: {
      StateTuoi: '1',
      StateKhuay: '1',
      StateRO: '1',
      StateXa: '1',
    },
    state: {
      StateBom: '1',
      StateKhuay: '1',
      StateTuoi: '0',
      StateRO: '0',
      StateXa: '1',
    },
  },
};

const convertData = (data = {}) => {
  return Object.keys(data).map((key) => {
    return {
      text: textDisplay[key] || '',
      status: data[key] || INACTIVE,
    };
  });
};

export default function Controller() {
  const onChangeStatus = (item) => {
    console.log('🚀 ~ onChangeStatus ~ item:', item);
  };

  return (
    <div className="mt-4">
      <main className="rounded-md g-color-box min-h-full">
        <div className="grid grid-cols-1 gap-4 lg:col-span-3 ">
            <div className="p-6">
              <div className="relative">
                <div className="relative  sm:overflow-hidden">
                  <div className="pb-3">
                    <div className="sm:block">
                      <div className="">
                        <nav
                          className="-mb-px flex space-x-4 overflow-x-auto"
                          aria-label="Tabs"
                        >
                        <div className="rounded-md  flex-1">
                          <h1 className="text-2xl text-white bg-[#566062] p-2 rounded-t-md">
                            Mini 1
                          </h1>
                          <div className="p-3 bg-[#ffffff80]">
                            <div className="text-gray-800 p-3 bg-[#DACEB4] rounded-md mb-3">
                              <Card
                                title="Button"
                                data={convertData(data.mini1.button)}
                                onChangeStatus={onChangeStatus}
                                isSwitchButton
                              />
                            </div>
                            <div className="text-gray-800 p-3 bg-[#DACEB4] rounded-md">
                              <Card title="State" data={convertData(data.mini1.state)} />
                            </div>
                          </div>
                        </div>
                        <div className="rounded-md  flex-1">
                          <h1 className="text-2xl text-white bg-[#566062] p-2 rounded-t-md">
                            Mini 2
                          </h1>
                          <div className="p-3 bg-[#ffffff80]">
                            <div className="text-gray-800 p-3 bg-[#DACEB4] rounded-md mb-3">
                              <Card
                                title="Button"
                                data={convertData(data.mini1.button)}
                                onChangeStatus={onChangeStatus}
                                isSwitchButton
                              />
                            </div>
                            <div className="text-gray-800 p-3 bg-[#DACEB4] rounded-md">
                              <Card title="State" data={convertData(data.mini1.state)} />
                            </div>
                          </div>
                        </div>
                        <div className="rounded-md  flex-1">
                          <h1 className="text-2xl text-white bg-[#566062] p-2 rounded-t-md">
                            Clone
                          </h1>
                          <div className="p-3 bg-[#ffffff80]">
                            <div className="text-gray-800 p-3 bg-[#DACEB4] rounded-md mb-3">
                              <Card
                                title="Button"
                                data={convertData(data.mini1.button)}
                                onChangeStatus={onChangeStatus}
                                isSwitchButton
                              />
                            </div>
                            <div className="text-gray-800 p-3 bg-[#DACEB4] rounded-md">
                              <Card title="State" data={convertData(data.mini1.state)} />
                            </div>
                          </div>
                        </div>
                        <div className="rounded-md  flex-1">
                          <h1 className="text-2xl text-white bg-[#566062] p-2 rounded-t-md">
                            Mini 1
                          </h1>
                          <div className="p-3 bg-[#ffffff80]">
                            <div className="text-gray-800 p-3 bg-[#DACEB4] rounded-md mb-3">
                              <Card
                                title="Button"
                                data={convertData(data.mini1.button)}
                                onChangeStatus={onChangeStatus}
                                isSwitchButton
                              />
                            </div>
                            <div className="text-gray-800 p-3 bg-[#DACEB4] rounded-md">
                              <Card title="State" data={convertData(data.mini1.state)} />
                            </div>
                          </div>
                        </div>
                        <div className="rounded-md  flex-1">
                          <h1 className="text-2xl text-white bg-[#566062] p-2 rounded-t-md">
                            Mini 1
                          </h1>
                          <div className="p-3 bg-[#ffffff80]">
                            <div className="text-gray-800 p-3 bg-[#DACEB4] rounded-md mb-3">
                              <Card
                                title="Button"
                                data={convertData(data.mini1.button)}
                                onChangeStatus={onChangeStatus}
                                isSwitchButton
                              />
                            </div>
                            <div className="text-gray-800 p-3 bg-[#DACEB4] rounded-md">
                              <Card title="State" data={convertData(data.mini1.state)} />
                            </div>
                          </div>
                        </div>
              
                        <div className="rounded-md  flex-1">
                          <h1 className="text-2xl text-white bg-[#566062] p-2 rounded-t-md">
                            Mother
                          </h1>
                          <div className="p-3 bg-[#ffffff80]">
                            <div className="text-gray-800 p-3 bg-[#DACEB4] rounded-md mb-3">
                              <Card
                                title="Button"
                                data={convertData(data.mini1.button)}
                                onChangeStatus={onChangeStatus}
                                isSwitchButton
                              />
                            </div>
                            <div className="text-gray-800 p-3 bg-[#DACEB4] rounded-md">
                              <Card title="State" data={convertData(data.mini1.state)} />
                            </div>
                          </div>
                        </div>
                        <div className="rounded-md  flex-1">
                          <h1 className="text-2xl text-white bg-[#566062] p-2 rounded-t-md">
                            Bloom 2
                          </h1>
                          <div className="p-3 bg-[#ffffff80]">
                            <div className="text-gray-800 p-3 bg-[#DACEB4] rounded-md mb-3">
                              <Card
                                title="Button"
                                data={convertData(data.mini1.button)}
                                onChangeStatus={onChangeStatus}
                                isSwitchButton
                              />
                            </div>
                            <div className="text-gray-800 p-3 bg-[#DACEB4] rounded-md">
                              <Card title="State" data={convertData(data.mini1.state)} />
                            </div>
                          </div>
                        </div>
                        </nav>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </main>
    </div>
  );
}

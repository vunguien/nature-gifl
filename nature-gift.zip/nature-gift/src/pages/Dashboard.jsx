import React, { useState } from 'react';
import img from '../map_preview.png';
import CardStatus from '../components/CardStatus';
import {
  bgSensorEnvObj,
  unitSensorEnv,
  ACTIVE,
  listCo2Mode,
} from '../constants/consts';

export default function Dashboard({ data }) {
  let [co2Mode, setCo2Mode] = useState('On');
  return (
    <div className="mt-4">
      <main className="rounded-md bg-color-box">
        <div className="mx-auto p-4 sm:p-4 lg:p-4 grid lg:grid-cols-2 gap-2 xl:grid-cols-2">
          <div className="">
            <img className="w-full p-2" src={img} alt="Map Preview" />
          </div>
          <div className="ml-5 flex-1 text-black ">
            <div className="flex content-between justify-between">
              <div className="flex-1 mr-5">
                <h2 className="text-black text-2xl mb-2"><b>{data.Roomname}</b></h2>
                <div className="w-full h-6 bg-[#DACEB4] rounded-full dark:bg-gray-700">
                  <div
                    className="h-6 bg-[#D2B678] rounded-full dark:bg-blue-500"
                    style={{ width: '80%' }}
                  ></div>
                </div>
                <div className="flex content-between justify-between flex-1">
                  <div>Time on</div>
                  <div>Time off</div>
                </div>
              </div>
              <div className="flex flex-col justify-center items-center w-24 h-24 rounded bg-[#DACEB4]">
                <div class="">Bloom Day</div>
                <div className=" text-5xl">{data.Day}</div>
              </div>
            </div>

            <div className="mt-10">
              <div class="grid grid-cols-3 max-[600px]:grid-cols-1">
                {/* ENVIROMENT */}
                <div class="mr-5">
                  <h2 className="text-xl mb-1">Environment</h2>
                  <div class="grid grid-rows-4 grid-flow-col gap-4 bg-color-state rounded-md p-3 text-sm min-h-[280px]">
                    {Object.keys(data.SensorEnvironment).map(
                      (key = {}, index) => {
                        return (
                          <div
                            className="flex items-center space-x-2"
                            key={index}
                          >
                            <div
                              className={`${bgSensorEnvObj[key]} w-10 h-10 rounded-md`}
                            ></div>
                            <div>
                              <div>{key}</div>
                              <div>
                                {data.SensorEnvironment[key]}
                                {unitSensorEnv[key]}
                              </div>
                            </div>
                          </div>
                        );
                      }
                    )}
                  </div>
                </div>
                {/* EC2 */}
                <div class="mr-5">
                  <h2 className="text-xl  mb-1">Sensor EC</h2>
                  <div class="grid grid-rows-4 grid-flow-col gap-4 bg-color-state rounded-md p-3 text-sm min-h-[280px]">
                    {Object.keys(data.SensorEC).map((key = {}, index) => {
                      return (
                        <div
                          className="flex items-center space-x-2"
                          key={index}
                        >
                          <div
                            className={`${bgSensorEnvObj[key]} w-10 h-10 rounded-md`}
                          ></div>
                          <div>
                            <div>{key}</div>
                            <div>{data.SensorEC[key]}-89%</div>
                          </div>
                        </div>
                      );
                    })}
                    <div>
                      <div className="flex items-center justify-center flex-1 w-full mb-1">
                        {listCo2Mode.map((item) => {
                          const activeMode = co2Mode === item.mode;
                          return (
                            <button
                              className={`px-2 ${
                                activeMode
                                  ? 'bg-red-500 text-white'
                                  : 'bg-gray-500'
                              }`}
                              onClick={() => setCo2Mode(item.mode)}
                            >
                              {item.text}
                            </button>
                          );
                        })}
                      </div>
                      <div className="flex items-center justify-center">
                        <button className={`px-3 py-1 mr-2 bg-blue-500 rounded-sm`}>
                          {data?.Co2Mode?.ValueOff || 0}
                        </button>
                        <button className={`px-3 py-1 bg-red-500 rounded-sm`}>
                          {data?.Co2Mode?.ValueOn || 0}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                {/* DEVICE */}
                <div class="mr-5">
                  <h2 className="text-xl  mb-1">Device</h2>
                  <div class="grid grid-rows-7 grid-flow-col bg-color-state rounded-md p-3 text-sm min-h-[280px]">
                    <CardStatus isOn={data.StateDen === ACTIVE} text="Đèn" />
                    <CardStatus isOn={data.StateBom === ACTIVE} text="Bơm" />
                    <CardStatus
                      isOn={data.StateKhuay === ACTIVE}
                      text="Khuấy"
                    />
                    <CardStatus isOn={data.StateTuoi === ACTIVE} text="Tưới" />
                    <CardStatus isOn={data.StateCo2 === ACTIVE} text="CO2" />
                    <CardStatus isOn={data.StateXa === ACTIVE} text="Xả" />
                    <CardStatus isOn={data.StateRO === ACTIVE} text="RO" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

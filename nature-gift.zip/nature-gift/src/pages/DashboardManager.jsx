import React from 'react';
import Card from '../components/Card';
import { INACTIVE, textDisplay } from '../constants/consts';
import img from '../map_preview.png';
import StateBox from '../components/StateBox';
import LineChart from './LineChart';

export default function DashboardManager1({ data }) {
  console.log(data);
  const onChangeStatus = (item) => {
    console.log('🚀 ~ onChangeStatus ~ item:', item);
  };

  return (
    <div className="m-2 p-6">
      <div className="min-h-1/2 max-h-1/2 mb-4">
        <div className="flex flex-row space-x-2">
          <div className="basis-1/6 rounded-xl bg-[#EFE3CA]">
            <div className="p-4 w-full h-full">
              <img className="w-full h-full" src={img} alt="Map Preview" />
            </div>
          </div>
          <div className="basis-1/6 rounded-xl bg-[#EFE3CA]">
            <div className="p-4 w-full h-full">
              <img className="w-full h-full" src={img} alt="Map Preview" />
            </div>
          </div>
          <div className="basis-1/3 rounded-xl bg-[#EFE3CA]">
            <div className="flex flex-row w-full h-full p-4 space-x-2">
              <div className="bg-red-500 basis-5/8 w-3/5">
                <div className="h-full">
                  <img className="h-full " src={img} alt="Map Preview" />
                </div>
              </div>
              <div className="basis-3/8 w-2/5 p-2 flex-0 h-full">
                <div className="grid gap-2">
                  <div className="text-black text-5xl font-light row-span-1">
                    Room 1
                  </div>
                  <div className=" bg-[#DACEB4] p-2">
                    <StateBox data={data} />
                  </div>
                  <div className="bg-[#DACEB4]">
                    <LineChart />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="basis-1/3 rounded-xl bg-[#EFE3CA]">
            <div className="flex flex-row w-full h-full p-4 space-x-2">
              <div className="bg-red-500 basis-5/8 w-3/5">
                <div className="h-full">
                  <img className="h-full  w-full" src={img} alt="Map Preview" />
                </div>
              </div>
              <div className="basis-3/8 w-2/5 p-2 flex-0 h-full">
                <div className="grid gap-2">
                  <div className="text-black text-5xl font-light row-span-1">
                    Room 1
                  </div>
                  <div className=" bg-[#DACEB4] p-2">
                    <StateBox data={data} />
                  </div>
                  <div className="bg-[#DACEB4]">
                    <LineChart />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="min-h-1/2 max-h-1/2">
        <div className="flex flex-row space-x-2">
          <div className="basis-1/6 rounded-xl bg-[#EFE3CA]">
            <div className="p-4 w-full h-full">
              <img className="w-full h-full" src={img} alt="Map Preview" />
            </div>
          </div>
          <div className="basis-1/6 rounded-xl bg-[#EFE3CA]">
            <div className="p-4 w-full h-full">
              <img className="w-full h-full" src={img} alt="Map Preview" />
            </div>
          </div>
          <div className="basis-1/3 rounded-xl bg-[#EFE3CA]">
            <div className="flex flex-row w-full h-full p-4 space-x-2">
              <div className="bg-red-500 basis-5/8 w-3/5">
                <div className="h-full">
                  <img className="h-full  w-full" src={img} alt="Map Preview" />
                </div>
              </div>
              <div className="basis-3/8 w-2/5 p-2 flex-0 h-full">
                <div className="grid gap-2">
                  <div className="text-black text-5xl font-light row-span-1">
                    Room 1
                  </div>
                  <div className=" bg-[#DACEB4] p-2">
                    <StateBox data={data} />
                  </div>
                  <div className="bg-[#DACEB4]">
                    <LineChart />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="basis-1/3 rounded-xl bg-[#EFE3CA]">
            <div className="flex flex-row w-full h-full p-4 space-x-2">
              <div className="bg-red-500 basis-5/8 w-3/5">
                <div className="h-full">
                  <img className="h-full w-full" src={img} alt="Map Preview" />
                </div>
              </div>
              <div className="basis-3/8 w-2/5 p-2 flex-0 h-full">
                <div className="grid gap-2">
                  <div className="text-black text-5xl font-light row-span-1">
                    Room 1
                  </div>
                  <div className=" bg-[#DACEB4] p-2">
                    <StateBox data={data} />
                  </div>
                  <div className="bg-[#DACEB4]">
                    <LineChart />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

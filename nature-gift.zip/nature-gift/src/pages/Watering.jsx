import React, { useState } from 'react';
import Card from '../components/Card';
import { INACTIVE, listWateringMode, textDisplay } from '../constants/consts';

const data = {
  mini1: {
    button: {
      StateTuoi: '1',
      StateKhuay: '1',
      StateRO: '1',
      StateXa: '1',
    },
    state: {
      StateBom: '1',
      StateKhuay: '1',
      StateTuoi: '0',
      StateRO: '0',
      StateXa: '1',
    },
  },
};

const convertData = (data = {}) => {
  return Object.keys(data).map((key) => {
    return {
      text: textDisplay[key] || '',
      status: data[key] || INACTIVE,
    };
  });
};

export default function Watering() {
  let [phase2Mode, setPhase2Mode] = useState('1');

  const onChangeStatus = (item) => {
    console.log('🚀 ~ onChangeStatus ~ item:', item);
  };
  return (
    <div className="mt-4">
      <main className="rounded-md bg-color-box">
        <div className="grid lg:grid-cols-2 xl:grid-cols-2 max-[600px]:grid-rows-2 gap-2 p-4">
          <div className="grid grid-cols-2 gap-4 p-4">
            <div className="flex flex-col items-center justify-center">
              <h1 className="text-3xl font-bold mb-6 text-black">Room 1</h1>
              <div className="w-40 h-[200px] bg-blue-500 dark:bg-gray-700 overflow-hidden inline-block">
                <div
                  className="w-30 bg-blue-300 dark:bg-blue-500 -rotate-0 transform origin-top-left"
                  style={{ height: '30%' }}
                ></div>
              </div>
            </div>
            <div className=" grid-rows-2 gap-4 p-4">
              <div className="p-3">
                <div className=" p-3 w-3/4 text-black bg-color-state rounded-md mb-3">
                  <Card title="State" data={convertData(data.mini1.state)} />
                </div>
                <div className=" p-3 w-3/4 text-black bg-color-state rounded-md">
                  <Card
                    title="Button"
                    data={convertData(data.mini1.button)}
                    onChangeStatus={onChangeStatus}
                    isSwitchButton
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="bg-[#EFE3CA] grid p-8 text-white">
            <div className="grid-rows-3 grid-flow-col gap-4">
              <div className="bg-[#EFE3CA] border-phase p-6 max-[600px]:p-2 mb-5">
                <h1 className="text-2xl text-black max-[600px]:text-xl">Phase 1</h1>
                <div className="grid grid-cols-2 gap-2 px-8 py-2">
                  <div className="">
                    <span className="pr-2 text-black">Start</span>
                    <span className="bg-[#DACEB4] text-black p-2">06:30:30</span>
                  </div>
                  <div className="">
                    <span className="pr-2 text-black">End</span>
                    <span className="bg-[#DACEB4] text-black p-2">06:30:30</span>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 px-8 py-2">
                  <div className="">
                    <span className="pr-2 text-black">Pump</span>
                    <span className="bg-[#DACEB4] text-black p-2">06:30:30</span>
                  </div>
                  <div className="">
                    <span className="pr-2 text-black">Loop</span>
                    <span className="bg-[#DACEB4] text-black p-2">06:30:30</span>
                  </div>
                </div>
              </div>
              <div className="bg-[#EFE3CA] border-phase p-6 max-[600px]:p-2 mb-5">
                <div className="flex justify-between">
                  <h1 className="text-2xl text-black max-[600px]:text-xl">Phase 2</h1>
                  <div className="rounded-md">
                    {listWateringMode.map((item) => {
                      const activeMode = phase2Mode === item.mode;
                      return (
                        <button
                          className={`px-2 w-16 ${
                            activeMode ? 'bg-blue-500 text-white' : 'bg-[#171717]'
                          }`}
                          onClick={() => setPhase2Mode(item.mode)}
                        >
                          {item.text}
                        </button>
                      );
                    })}
                  </div>
                </div>
                <div className="grid grid-cols-1 gap-2 px-8 py-2">
                  <div className="grid grid-cols-3 gap-2">
                    <span className="pr-2 text-black">Sensor</span>
                    <input className="bg-[#DACEB4] text-black p-2 mr-2 h-6 w-20"></input>
                    <input className="bg-[#DACEB4] text-black p-2 h-6 w-20"></input>
                  </div>
                </div>
                <div className="grid grid-cols-1 gap-2 px-8 py-2">
                  <div className="grid grid-cols-4 gap-2">
                    <span className="pr-2 text-black">%On</span>
                    <input
                      className="bg-[#DACEB4] text-black p-2 mr-2 h-6 w-20"
                      value="70%"
                    ></input>
                    <input
                      className="bg-[#DACEB4] text-black p-2 h-6 w-20"
                      value="%Off"
                    ></input>
                    <input
                      className="bg-[#DACEB4] text-black  p-2 h-6 w-20"
                      value="90%"
                    ></input>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <button className="rounded-md bg-[#DACEB4] px-3.5 py-2.5 text-sm font-semibold text-black shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 mr-5">
                  Save
                </button>
                <button className="rounded-md bg-[#DACEB4] px-3.5 py-2.5 text-sm font-semibold text-black shadow-sm hover:bg-red-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-600">
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
